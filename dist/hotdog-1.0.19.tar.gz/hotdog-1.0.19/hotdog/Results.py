import unittest
from hotdog.Mustard import *


class UploadResults(unittest.TestResult):
    projectFolder = os.environ['PROJECTFOLDER']

    def addError(self, test, err):
        stack = self._exc_info_to_string(err, test)
        error_message = self.get_error_message(err, stack)

        UploadToMustard(test, 'fail', error_message=error_message, stacktrace=stack)
        self.RemoveApp(test)

        super().addError( test, err)
        print("Testcase [%s] ended with status [%s] on device [%s]\n %s" % (test._testMethodName,
                                                                       'ERROR',
                                                                       test.options['deviceName'],
                                                                       stack))
    def addFailure(self, test, err):
        stack = self._exc_info_to_string(err, test)
        error_message =  self.get_error_message(err, stack)

        UploadToMustard(test, 'fail', error_message=error_message, stacktrace=stack)

        self.RemoveApp(test)

        super().addFailure(test, err)
        print("Testcase [%s] ended with status [%s] on device [%s] \n %s" % (test._testMethodName,
                                                                       'FAIL',
                                                                       test.options['deviceName'],
                                                                       stack))

    def addSuccess(self, test):
        UploadToMustard(test, 'pass')
        self.RemoveApp(test)
        super().addSuccess(test)
        print("Testcase [%s] ended with status [%s] on device [%s]" % (test._testMethodName,
                                                                       'PASS',
                                                                       test.options['deviceName']))

    def get_error_message(self, error, stacktrace):
        try:
            errmsg=  str(error[1])
            if len(errmsg) > 100:
                return errmsg[0:100]
            else:
                return errmsg
        except:
            stackArray = stacktrace.split('\n')
            stackArray.reverse()
            for stack in stackArray:
                if len(stack) > 5:
                    splitMessage = stack.split(':')
                    return splitMessage[len(splitMessage)-1]

    def RemoveApp(self, test):
        if 'mobile' in test.options['provider']:
            try: test.driver.close_app()
            except: pass
            try: test.driver.remove_app(GetConfig('IOS_BUNDLE_ID'))
            except: pass
            try: test.driver.remove_app(GetConfig('ANDROID_BUNDLE_ID'))
            except: pass
        try: test.driver.quit()
        except: pass